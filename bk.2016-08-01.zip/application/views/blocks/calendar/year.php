
<?if(1==0):?>


<?php
	$calendarItems = $calendar->getYear();
	$appts = [];
	
	if(!empty($calendarItems)){
		reset($calendarItems);
		$appt_from = key($calendarItems);
		end($calendarItems);
		$appt_to = key($calendarItems);
		$appts = $this->customers_model->getSchedule($appt_from, $appt_to);
	}
	
	
	
	echo '<pre>';
	echo "$appt_from --> $appt_to";
	print_r($calendarItems);
	echo '</pre>';
?>



<div class="calendar month">
	
	
	<?foreach($calendarItems as $date => $opt):?>
	<div id="col-<?=$date?>" class="col cell <?=$opt->classes?>">
		<b><?=$opt->month?></b>
		<?if(!empty($appts[$date])):?>
		<div class="points">
		<?foreach($appts[$date] as $appt):?><i class="point" data-id="<?=$appt->id?>"></i><?endforeach;?>
		</div>
		
		<div class="chevron"><i class="glyphicon glyphicon-chevron-up"></i></div> 
		<?endif;?>
	</div>
	
	<?endforeach;?>
	
	

	<ul class="appts">
		<?foreach($calendarItems as $date => $opt): if(!empty($appts[$date])): foreach($appts[$date] as $appt):?>
		<li data-col="col-<?=$date?>" data-id="<?=$appt->id?>">
			<a href="#">
			<div class="point"></div>
			<div class="name capit"><?=$appt->name?></div>
			<div class="time">(<?=date('h:i A',strtotime($appt->datetime))?>)</div>
			</a>
			
			<div class="btns">
				<button class="btn btn-danger btn-sm margin-right-10 delete-appt" data-id="<?=$appt->id?>"><i class="ti-close"></i></button>
				<button class="btn btn-primary btn-sm pull-right edit-appt" data-id="<?=$appt->customer_id?>"><i class="ti-pencil"></i></button>
			</div>
			
		</li>
		<?endforeach; endif; endforeach;?>
	</ul>		

	
	
</div>

<?endif;?>