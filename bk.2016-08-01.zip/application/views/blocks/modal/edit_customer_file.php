
<div class="modal fade" id="customerFileModal" tabindex="-1" role="dialog" aria-labelledby="customerFileModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="customerFileModalLabel"><i class="ti-pencil"></i></h4>
      </div>
     
      <form class="save-user">
      <div class="modal-body">
	        <p>
            	Title:
        	</p>        
	        <div class="form-group">
	            <input type="text" class="form-control" name="rename">
	        </div>                
			<input type="hidden" name="id" />
			<div class="msg"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary save">Save</button>
      </div>
      </form>
    </div>
  </div>
</div>